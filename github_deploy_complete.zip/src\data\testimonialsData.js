export const testimonials = [
    {
        id: 1,
        name: "Rahul Verma",
        location: "Unnao City",
        comment: "My 55-inch Sony TV screen was broken. Vijay Electronics replaced it at a very reasonable price. Picture quality is just like new!",
        rating: 5
    },
    {
        id: 2,
        name: "Amit Singh",
        location: "Shuklaganj",
        comment: "Excellent service! My Samsung TV had a motherboard issue. They repaired it within 2 hours. Very professional staff.",
        rating: 5
    },
    {
        id: 3,
        name: "Priya Gupta",
        location: "Civil Lines, Unnao",
        comment: "Best TV repair shop in Unnao. The home service was quick and the technician was very polite.",
        rating: 4
    }
];
