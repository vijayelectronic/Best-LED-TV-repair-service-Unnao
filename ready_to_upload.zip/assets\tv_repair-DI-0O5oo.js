const e="/Best-LED-TV-repair-service-Unnao/assets/tv_repair-D2aJTHo6.png";export{e as t};
